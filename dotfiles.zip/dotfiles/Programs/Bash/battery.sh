#!/usr/bin/env bash

#This program is intended to:
# Show battery percentage
# Show associated battery icon
# Work with i3blocks

#Get percentage
percentage=$(upower -i /org/freedesktop/UPower/devices/battery_BAT0 | grep -E "percentage:" | grep -o '....$')

rm debug

#Remove percentage sign
percentageValue=${percentage::-1}
#percentageValue=$((percentageValue)) #This is how u can do arithmetic on it

#If 85-100
if (($percentageValue > 84)); then
	#Display full
	emoji=

#If 62-84
elif (($percentageValue > 61)); then
	#Display 3/4
	emoji=

#If 39-61
elif (($percentageValue > 38)); then
	#Display 1/2
	emoji=

#If 16-38
elif (($percentageValue > 15)); then
	#Display 1/4
	emoji=

#If 0-15
elif (($percentageValue > -1)); then
	#Display empty
	emoji=
fi

echo $emoji $percentageValue%
