#!/usr/bin/env bash

# set the icon and a temporary location for the screenshot to be stored
currBG="$HOME/screen.png"

# take a screenshot
scrot "$currBG"

# blur the screenshot by resizing and scaling back up
#convert "$currBG" -filter Gaussian -thumbnail 20% -sample 500% "$currBG"
convert $currBG -scale 5% -scale 2000% $currBG

# overlay the icon onto the screenshot
[[ -f $1 ]] && convert $currBG $1 -gravity center -composite -matte $currBG
#dbus-send --print-reply --dest=org.mpris.MediaPlaer2.spotify /org/mpris/MediaPlayer2 org.mpris.MediaPlayer2.Player.Stop

# lock the screen with the blurred screenshot
i3lock -i "$currBG"
rm $currBG
