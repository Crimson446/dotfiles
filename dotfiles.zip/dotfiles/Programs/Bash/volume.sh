#!/usr/bin/env bash

#This program is intended to:
# Show volume percentage
# Show associated volume icon
# Work with i3blocks

#Remove volume
volumeValue=$(pamixer --get-volume)

#If 75-100
if (($volumeValue > 74)); then
	#Display full
	emoji=

#If 50-74
elif (($volumeValue > 49)); then
	#Display half
	emoji=

#If 1-49
elif (($volumeValue > 0)); then
	#Display empty
	emoji=

#If 0
elif (($volumeValue > -1)); then
	#Display muted
	emoji=
fi

muted=$(pamixer --get-mute)

if [[ $muted == "true" ]]; then
	emoji=
fi

echo $emoji $volumeValue%
