//Libraries I didn't make
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <SDL2/SDL.h>
#include <GL/glew.h>
#include <SDL2/SDL_opengl.h>
#include <GL/glu.h>

//Libraries I made
#include "Engine/Engine.h"

int main(int argc, char* args[])
{
	//printf("DEBUG: `main()` started.\n");
	if (!ENGINE_Init()) //Initialize engine
		return -1; //Stop if it fails
	//printf("DEBUG: Engine initialized\n");
	
	ENGINE_CreateWindow("Gamer window", ENGINE_ScreenWidth, ENGINE_ScreenHeight);
	//printf("DEBUG: Window created.\n");
	
	//Create a shader program
	unsigned int testShader = ENGINE_CreateShader("Shaders/basicShader.vert", "Shaders/basicShader.frag", "NULL_FILE");
	
	//Make vertices & indices
	float vertices[] =
	{
		//Positions              Colors               Texture coords
		//X     Y        Z       Red   Green Blue    S     T
		 0.5f,   0.5f,   1.0f,   1.0f, 0.0f, 0.0f,   1.0f, 1.0f, //Top right
		 0.5f,  -0.5f,   1.0f,   0.0f, 1.0f, 0.0f,   1.0f, 0.0f, //Bottom right
		-0.5f,  -0.5f,   1.0f,   0.0f, 0.0f, 1.0f,   0.0f, 0.0f, //Bottom left
		-0.5f,   0.5f,   1.0f,   1.0f, 1.0f, 0.0f,   0.0f, 1.0f  //Top left
	};
	
	unsigned int indices[] =
	{
		0, 1, 3, //First triangle
		1, 2, 3  //Second triangle
	};
	
	/* Buffer madness */
	
	//make VBO, VAO
	unsigned int VBO, VAO, EBO;
	//vertex array object
	//vertex buffer objects
	//i forgor
	
	//gen vertex arrays for VAO
	glGenVertexArrays(1, &VAO);
	//gen buffers for VBO
	glGenBuffers(1, &VBO);
	//gen buffers for EBO
	glGenBuffers(1, &EBO);
	
	//bind vertex array for VAO
	glBindVertexArray(VAO);
	
	//Buffer data for VBO
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
	
	//Buffer data for EBO
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
	
	//Position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	
	//Color attribute
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	
	//Texture coord attribute
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);
	
	/* Texture shit */
	
	//Load and create some textures
	unsigned int texture1, texture2;
	texture1 = loadTexture("Assets/Textures/container.jpg");
	texture2 = loadTexture("Assets/Textures/Duck.png");
	
	ENGINE_UseShader(testShader);
	
	ENGINE_ShaderUniformInt(testShader, "texture1", 0);
	ENGINE_ShaderUniformInt(testShader, "texture2", 1);
	
	bool quit = false;
	
	SDL_Event event;
	
	//printf("DEBUG: Made it to game loop\n");
	
	//Main loop
	while (!quit)
	{
		//Handle events on queue
		while (SDL_PollEvent(&event) != 0)
		{
			switch (event.type)
			{
				case SDL_QUIT:
					quit = true;
					break;
			}
		}
		glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);
		
		//Bind texture
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture1);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, texture2);
		
		mat4 transform = identityMat4(1.0f);
		
		transform = rotateMat4aboutVec3(transform, 45.0f, Vector3fConstructor(1.0f, 0.0f, 0.0f));
		
		mat4 model = identityMat4(1.0f);
		model = rotateMat4aboutVec3(model, -55.0f, Vector3fConstructor(1.0f, 0.0f, 0.0f));
		
		mat4 view = identityMat4(1.0f);
		view = translateMat4Vec3f(view, Vector3fConstructor(0.0f, 0.0f, 3.0f));
		
		mat4 proj = perspectiveCamConstructor(	45.0f, //FOV
												(float)ENGINE_ScreenWidth / (float)ENGINE_ScreenHeight, //Aspect ratio
												0.1f, //Near Clip
												100.0f); //Far clip
		
		//printf("DEBUG: Projection:\n"); debugPrintMat4(proj);
		
		//Vector4f exampleVert = {vertices[0], vertices[1], vertices[2], 1.0f};
		//mat4 exampleMat = multiplyMat4Mat4(multiplyMat4Mat4(model, view), proj);
		//exampleVert = multiplyMat4Vec4f(exampleMat, exampleVert);
		//printf("DEBUG: Final position of 1st vertex is <%f, %f, %f, %f>\n", exampleVert.x, exampleVert.y, exampleVert.z, exampleVert.w);
		
		/* Draw triangle */
		
		ENGINE_UseShader(testShader);
		
		//Transformation stuff
		ENGINE_ShaderUniformMat4(testShader, "projection", &proj);
		ENGINE_ShaderUniformMat4(testShader, "view", &view);
		ENGINE_ShaderUniformMat4(testShader, "model", &model);
		
		//Render container
		glBindVertexArray(VAO);
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
		
		//Rendering
		//ENGINE_Render();
		
		SDL_GL_SwapWindow(ENGINE_Window);
	}
	
	ENGINE_Stop();
	
	return 0;
}
